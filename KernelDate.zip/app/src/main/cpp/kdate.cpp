#include <sys/utsname.h>
#include <cstdint>
#include <cstring>
#include <android/log.h>

// Change the date here AND in MainHook.java
static const char kVersion[] = "#1 SMP PREEMPT Thu Nov  5 19:18:45 UTC 2026";

typedef int (*HookFunType)(void *func, void *replace, void **backup);
typedef int (*UnhookFunType)(void *func);
typedef void (*NativeOnModuleLoaded)(const char *name, void *handle);
typedef struct {
    uint32_t version;
    HookFunType hook_func;
    UnhookFunType unhook_func;
} NativeAPIEntries;

static int (*orig_uname)(struct utsname *) = nullptr;

static int my_uname(struct utsname *buf) {
    int ret = orig_uname(buf);
    if (ret == 0 && buf != nullptr) {
        strlcpy(buf->version, kVersion, sizeof(buf->version));
    }
    return ret;
}

static void on_library_loaded(const char *, void *) {}

extern "C" __attribute__((visibility("default")))
NativeOnModuleLoaded native_init(const NativeAPIEntries *entries) {
    int rc = entries->hook_func(reinterpret_cast<void *>(&uname),
                                reinterpret_cast<void *>(my_uname),
                                reinterpret_cast<void **>(&orig_uname));
    __android_log_print(ANDROID_LOG_INFO, "KernelDate", "uname hook result: %d", rc);
    return on_library_loaded;
}
