cmake_minimum_required(VERSION 3.22.1)
project(kdate CXX)
add_library(kdate SHARED kdate.cpp)
target_link_libraries(kdate log)
