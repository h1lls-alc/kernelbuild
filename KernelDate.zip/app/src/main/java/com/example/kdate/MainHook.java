package com.example.kdate;

import android.system.Os;
import android.system.StructUtsname;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {
    // Change the date here AND in kdate.cpp
    private static final String VERSION = "#1 SMP PREEMPT Thu Nov  5 19:18:45 UTC 2026";

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (lpparam.packageName.equals("com.example.kdate")) return;

        // Native hook: uname(2) called from C/C++ code
        try {
            System.loadLibrary("kdate");
        } catch (Throwable t) {
            XposedBridge.log(t);
        }

        // Java hook: android.system.Os.uname()
        try {
            XposedHelpers.findAndHookMethod(Os.class, "uname", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    StructUtsname u = (StructUtsname) param.getResult();
                    if (u == null) return;
                    param.setResult(new StructUtsname(
                            u.sysname, u.nodename, u.release, VERSION, u.machine));
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(t);
        }
    }
}
